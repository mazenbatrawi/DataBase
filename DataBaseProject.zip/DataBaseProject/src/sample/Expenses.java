package sample;

import java.util.Date;

public class Expenses {
    private String id, description;
    private Date date;
    private double value;

    public Expenses(String id, String description, Date date, double value) {
        this.id = id;
        this.description = description;
        this.date = date;
        this.value = value;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
}
