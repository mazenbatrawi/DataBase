module DataBaseProject {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.sql;
    requires mysql.connector.java;
    requires javafx.web;

    opens sample;
}